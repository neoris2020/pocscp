sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Neoris/ZPM_EQUIPOS/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("Neoris.ZPM_EQUIPOS.Component", {

		metadata: {
			manifest: "json",
			config: {
				"resourceBundle": "i18n/i18n.properties",
				"titleResource": "appTitle"
			}
		},
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			var oRootPath = jQuery.sap.getModulePath("Neoris.ZPM_EQUIPOS"); // your resource root

			var oImageModel = new sap.ui.model.json.JSONModel({
				path: oRootPath
			});

			this.setModel(oImageModel, "imageModel");

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});