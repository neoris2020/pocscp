sap.ui.define([
	"Neoris/ZPM_EQUIPOS/test/unit/controller/Index.controller"
], function () {
	"use strict";
});