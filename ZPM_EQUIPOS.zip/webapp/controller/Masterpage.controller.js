sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, Fragment, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("Neoris.ZPM_EQUIPOS.controller.Masterpage", {
		onInit: function () {
			this.onIniciarModelo();
		},

		onAbrirMatchcode: function (oEvent) {
			Fragment.load({
				name: "Neoris.ZPM_EQUIPOS.fragments.ValueHelp",
				controller: this
			}).then(function (oFragment) {
				oFragment._oSearchField.setShowSearchButton(false)
				this.getView().addDependent(oFragment);
				oFragment.open();
			}.bind(this));
		},

		onAgregarValorInputDeMatchcode: function (oEvent) {
			var sTitle = oEvent.mParameters.selectedItem.getTitle()
			this.byId('input_numero_equipo').setValue(sTitle)
		},


		onLiveChange: function (oEvent) {
			var filterValue = 'Equnr'
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter(filterValue, FilterOperator.EQ, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		onIniciarModelo: function () {
			var oView = this.getView();
			var oModel = new JSONModel({
				"NumeroEquipo": "000000000010000002"
			});
			oView.setModel(oModel, "ViewModel");
		},

		onBuscar: async function () {
			var oView = this.getView();
			var oModel = oView.getModel("ViewModel");

			var oNumeroEquipo = oModel.getProperty("/NumeroEquipo");
			var oValidado = oNumeroEquipo.trim() != "" ? true : false;

			if (!oValidado) {
				this._AbrirMensajeError("Complete el campo de numero de equipo");
				return;
			}

			const that = this;
			const oACMODATA = this.getOwnerComponent().getModel();
			const oURL = `/getDetalleEquipoSet('${oNumeroEquipo}')`;
			
			this._AbrirModalCargaDatos();
			try {
				await new Promise(resolve => {
					oACMODATA.read(oURL, {
						urlParameters: {
							"$expand": "DetalleNavHistoricos,DetalleNavPendientes,DetalleNavUbicaciones"
						},
						success: async function (response, headerResponse) {
							that._CerrarModalCargaDatos();
							that.getOwnerComponent().getModel("EQUIPO").setData(response);
							that.getOwnerComponent().getModel("EQUIPO").refresh(true);

							var oDevice 	= sap.ui.Device.system;
							if(oDevice.phone){
								var oSplitApp   = that.getView().getParent().getParent();
							    var oDetailPage = oSplitApp.getDetailPages()[0];
							    oSplitApp.toDetail(oDetailPage, "slide");
							}
							// that.getRouter().navTo("DetailPage");
							resolve();
						},
						error: async function (response) {
							try {
								var oJson = JSON.parse(response.responseText);
								var oMessage = oJson.error.message.value;
							} catch (e) {
								var oMessage = "Ha ocurrido un error";
							}
							that._CerrarModalCargaDatos();
							await that._AbrirMensajeError(oMessage);
							resolve();
						}
					});
				});
			} catch (e) {
				that._CerrarModalCargaDatos();
			}
		}

	});

});