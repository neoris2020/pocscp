sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	
	"sap/ui/core/routing/History"
], function (Controller , JSONModel, History) {
	"use strict";

	return Controller.extend("Neoris.ZPM_EQUIPOS.controller.Detail", {
		onInit: function(){
			var oGlobalData = this.getOwnerComponent().getModel("EQUIPO").getData();
			// this.getRouter().getTarget("Page1").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
		},
		
		onNavBack: function (oEvent) {
			var oDevice 	= sap.ui.Device.system;
			if(oDevice.phone){
				var oSplitApp = this.getView().getParent().getParent();
			    var oMaster = oSplitApp.getMasterPages()[0];
			    oSplitApp.toMaster(oMaster, "slide");
			}
		},
		
		handleRouteMatched: function(oEvent) {
			
		}
	});

});