sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	'sap/ui/model/odata/v2/ODataModel',
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageBox'
], function (Controller, History, UIComponent, ODataModel, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("Neoris.ZPM_EQUIPOS.controller.BaseController", {
		
		_OdataRequest: async function ( oUrl, oFiltros = [], oAbrirMensajeCarga = true, oMostrarMensajeExito = false, oMostrarError = true, oMostrarErrorResultado = false) {
			var that = this;
			var oOdata = this.getOwnerComponent().getModel('KAUFMANN');

			oOdata.setUseBatch(false);
			var oResponseRequest;

			if (oAbrirMensajeCarga) {
				this._AbrirModalCargaDatos();
			}

			try {
				await new Promise(resolve => {
					oOdata.read(oUrl, {
						filters: oFiltros,
						success: async function (response, headerResponse) {
							oResponseRequest = response.results;
							var oRetornar = await that._EjecutarMensajesRequest(
								headerResponse, 
								response, 
								oMostrarMensajeExito, 
								oMostrarError,
								oMostrarErrorResultado
							);
							
							if (!oRetornar) {
								oResponseRequest = false;
							}
							resolve();
						},
						error: async function (response) {
							if (oMostrarError) {
								oResponseRequest = false;
								await that._AbrirMensajeError("Ha ocurrido un error");
							}
							resolve();
						}
					});
				});
			} catch (error) {
				if (oAbrirMensajeCarga) {
					this._CerrarModalCargaDatos();
				}
				return false;
			}

			if (oAbrirMensajeCarga) {
				this._CerrarModalCargaDatos();
			}

			return oResponseRequest;
		},
		
		_EjecutarMensajesRequest: async function (
			oHeaderResponse,
			oResponse = false,
			oMostrarMensajeExito = false,
			oMostrarError = false,
			oMostrarErrorResultado = false) 
		{
			var oHeaderObject = oHeaderResponse.headers["sap-message"];
			var oMessage = false;
			var oErrorMessage = false;
			var oInfoMessage = false;
			var oWarningMessage = false;
			var oSuccessMessage = false;

			var oReturn = true;

			if (oHeaderObject) {
				var oHeader = JSON.parse(oHeaderObject);
				if (oHeader) {
					oErrorMessage = '';
					oInfoMessage = '';
					oWarningMessage = '';
					oSuccessMessage = '';
					if (oHeader["message"]) {
						oMessage = oHeader.message;
						var oSeverity = oHeader.severity;
						switch (oSeverity) {
						case 'error':
							oErrorMessage += '- ' + oMessage + '\n';
							break;
						case 'info':
							oInfoMessage += '- ' + oMessage + '\n';
							break;
						case 'warning':
							oWarningMessage += '- ' + oMessage + '\n';
							break;
						case 'success':
							oSuccessMessage += '- ' + oMessage + '\n';
							break;
						default:
							break;
						}
					}
					if (oHeader.details.length > 0) {
						var oDetalles = oHeader.details;
						oDetalles.forEach(detalle => {
							if (detalle.severity == "error") {
								oErrorMessage += '- ' + detalle.message + '\n';
							} else if (detalle.severity == "info") {
								oInfoMessage += '- ' + detalle.message + '\n';
							} else if (detalle.severity == "warning") {
								oWarningMessage += '- ' + detalle.message + '\n';
							} else {
								oSuccessMessage += '- ' + detalle.message + '\n';
							}

						});
					}
				}
			}

			if (oInfoMessage) {
				await this._AbrirMensajeInfo(oInfoMessage);
			}

			if (oWarningMessage) {
				await this._AbrirMensajeWarning(oWarningMessage);
			}

			if (oErrorMessage) {
				if (oMostrarError) {
					await this._AbrirMensajeError(oErrorMessage);
				}
				oReturn = false;
			} else {
				if (oResponse && oMostrarErrorResultado) {
					var oCantResultados = oResponse.results;
					if (oCantResultados.length == 0) {
						if (oMostrarErrorResultado) {
							await this._AbrirMensajeError(oMostrarErrorResultado);
						}
						oReturn = false;
					}
				}
				if (oMostrarMensajeExito && oReturn) {
					await this._AbrirMensajeExito(oMostrarMensajeExito);
				}
			}

			return oReturn;
		},

		_AbrirModalCargaDatos: function () {
			if (!this._ModalCargaDatos) {
				this._ModalCargaDatos = sap.ui.xmlfragment("Neoris.ZPM_EQUIPOS.fragments.CargaDatos", this);
				this.getView().addDependent(this._ModalCargaDatos);
			}
			this._ModalCargaDatos.open();
		},

		_CerrarModalCargaDatos: function () {
			this._ModalCargaDatos.close();
		},

		_AbrirMensajeError: function (mensaje) {
			return new Promise(resolve => {
				MessageBox.error(
					mensaje, {
						styleClass: "sapUiSizeCompact",
						onClose: function () {
							resolve();
						}
					}
				)
			});
		},

		_AbrirMensajeWarning: function (mensaje) {
			return new Promise(resolve => {
				MessageBox.warning(
					mensaje, {
						styleClass: "sapUiSizeCompact",
						onClose: function () {
							resolve();
						}
					}
				)
			});
		},
		
		_AbrirMensajeConfirmacionAccion: function (mensaje) {
			return new Promise(resolve => {
				MessageBox.confirm( mensaje, {
					styleClass: "sapUiSizeCompact",
					actions: ["ACEPTAR", "CANCELAR"],
					onClose: function (oAction) {
						resolve(oAction);
					}
				});
			});
			
		},

		_AbrirMensajeExito: function (mensaje) {
			return new Promise(resolve => {
				MessageBox.success(
					mensaje, {
						styleClass: "sapUiSizeCompact",
						onClose: function () {
							resolve();
						}
					}
				)
			});
		},

		_AbrirMensajeInfo: function (mensaje) {
			return new Promise(resolve => {
				MessageBox.information(
					mensaje, {
						styleClass: "sapUiSizeCompact",
						onClose: function () {
							resolve();
						}
					}
				)
			});
		},

		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		onNavBack: function () {
			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("Inicio");
			}
		}
	});

});